# YouTube Video Summarizer

A simple Streamlit web app that summarizes YouTube video transcripts using Google Gemini.

## Features

- Extracts transcript from YouTube video
- Generates concise summary using Gemini Pro
- Downloadable summary text
- Toggle raw transcript view

## Setup Instructions

1. Clone the repo or unzip the project.
2. Create a `.env` file using `.env.example` and add your Google API key.
3. Install the requirements:
   ```bash
   pip install -r requirements.txt
   ```
4. Run the app:
   ```bash
   streamlit run app.py
   ```