import streamlit as st
from summarize import summarize_video, extract_transcript
import os
from dotenv import load_dotenv

load_dotenv()

st.set_page_config(page_title="YouTube Video Summarizer", layout="centered")
st.title("🎥 YouTube Video Summarizer")
st.write("Summarize YouTube videos using Google Gemini.")

video_url = st.text_input("Enter YouTube Video URL:")

if video_url:
    with st.spinner("Extracting transcript..."):
        transcript = extract_transcript(video_url)
        if transcript:
            st.success("Transcript extracted!")
            if st.checkbox("Show transcript"):
                st.text_area("Transcript", value=transcript, height=200)
            
            with st.spinner("Summarizing..."):
                summary = summarize_video(transcript)
                st.success("Summary generated!")
                st.text_area("Summary", value=summary, height=200)
                st.download_button("Download Summary", summary, file_name="summary.txt")
        else:
            st.error("Could not extract transcript. Check URL or try again.")
    st.markdown("---")