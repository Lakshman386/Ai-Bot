import streamlit as st
from transcript_extractor import get_transcript
from summarize import generate_summary
import os

st.set_page_config(page_title="YouTube Video Summarizer", layout="wide")
st.title("🎥 YouTube Video Summarizer")
st.markdown("Summarize any YouTube video using OpenAI's GPT API.")

url = st.text_input("Enter YouTube Video URL:")
if st.button("Summarize"):
    if url:
        with st.spinner("Fetching transcript..."):
            transcript = get_transcript(url)
        if transcript:
            st.success("Transcript fetched successfully.")
            with st.spinner("Generating summary..."):
                summary = generate_summary(transcript)
            st.subheader("📝 Summary")
            st.write(summary)
            st.download_button("Download Summary", summary, file_name="summary.txt")
            with st.expander("📄 Raw Transcript"):
                st.write(transcript)
        else:
            st.error("Transcript could not be retrieved.")